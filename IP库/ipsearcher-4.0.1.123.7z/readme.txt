﻿IP查询工具DLL使用说明

当前版本:4.0.1.123

该DLL可查询QQWry.dat(CNSS格式纯真版公网IPv4数据库)、QQWry.db(IPDB格式纯真公网IPv4数据库)、IPv6Wry.db(ZX版公网IPv6数据库)和MyIP.dbf(自定义IPv4和IPv6数据库)三个数据库中的IP地址对应的地理位置。
使用接口请看h文件。
数据库必须与DLL文件放在一起。
代码写得太烂,暂不打算开源。


QQWry.dat下载地址:(每5天更新)
http://update.cz88.net/ip/copywrite.rar
http://update.cz88.net/ip/qqwry.rar

IPv6Wry.db下载地址:(不定期更新)
http://ip.zxinc.org/ip/ip.7z

MyIP.dbf格式说明
STARTIP/ENDIP	开始/结束IP地址,必须按格式补足15位,中间加点	例: 010.001.022.123
STARTIPV6/ENDIPV6	开始/结束IPv6地址前4段,必须按格式补足16位,中间没有冒号	例: 20010DA880010000
COUNTRY	地区字符串1
LOCAL	地区字符串2

