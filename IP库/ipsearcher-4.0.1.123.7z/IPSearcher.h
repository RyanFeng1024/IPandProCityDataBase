/*
 * IPSearcher.h
 * 版本 4.1
 * 版权所有 (C) 2010-2019 ZX Inc.
 */

#ifndef IPS_H_
#define IPS_H_

#ifdef __cplusplus
extern "C" {
#endif

#define COMPAT_VER	0xFF	// 此版本及以下的数据库格式都是兼容的

#define DB_MYIPV4  1
#define DB_QQWRY   2
#define DB_IPV6WRY 4
#define DB_MYIPV6  8
#define DB_QQWRYDB 16
#define DB_MYIP    (DB_MYIPV4|DB_MYIPV6)
#define DB_ALL     (DB_MYIP|DB_QQWRY|DB_IPV6WRY)

#ifndef TAGADDR
#define TAGADDR
#define ADDR_MAX 2
typedef struct{
	union{
		char *c[ADDR_MAX];
		char *Content[ADDR_MAX];
	}
}Addr, *pAddr;
typedef struct{
	union{
		wchar_t *c[ADDR_MAX];
		wchar_t *Content[ADDR_MAX];
	}
}AddrW, *pAddrW;
/*
 * pAddr  也可定义为 char   ** 类型
 * pAddrW 也可定义为 wchar_t** 类型
 */
//typedef char** pAddr;
//typedef wchar_t** pAddrW;
#endif

#ifndef WINAPI
#ifdef WIN32
#define WINAPI	__stdcall
#else
#define WINAPI
#endif
#endif

#ifdef WIN32
char*	__cdecl	DateTime	();
pAddr	__cdecl	_GetAddress	(const char   * ip);	// 返回值为全局静态变量，线程不安全
pAddr	__cdecl	GetAddressInt	(unsigned int ip);	// 返回值为全局静态变量，线程不安全
unsigned int __cdecl IPCount	();
int	__cdecl	LookupAddress	(const char   * ip, pAddr  address);
int	__cdecl	Reload		();
#endif

pAddr	WINAPI	GetAddressA	(const char   * ip);	// 返回值为全局静态变量，线程不安全
pAddrW	WINAPI	GetAddressW	(const wchar_t* ip);	// 返回值为全局静态变量，线程不安全
pAddr	WINAPI	GetAddressIntV4A	(unsigned int ip);	// 返回值为全局静态变量，线程不安全
pAddrW	WINAPI	GetAddressIntV4W	(unsigned int ip);	// 返回值为全局静态变量，线程不安全
pAddr	WINAPI	GetAddressIntV6A	(unsigned __int64 iplow, unsigned __int64 iphigh);	// 返回值为全局静态变量，线程不安全
pAddrW	WINAPI	GetAddressIntV6W	(unsigned __int64 iplow, unsigned __int64 iphigh);	// 返回值为全局静态变量，线程不安全
unsigned __int64 WINAPI GetRecordCount	(unsigned int idb);
bool	WINAPI	IsIpv4A		(const char   * ip);
bool	WINAPI	IsIpv4W		(const wchar_t* ip);
bool	WINAPI	IsIpv6A		(const char   * ip);
bool	WINAPI	IsIpv6W		(const wchar_t* ip);
int	WINAPI	LookupAddressA	(const char   * ip, pAddr  address);
int	WINAPI	LookupAddressW	(const wchar_t* ip, pAddrW address);
int	WINAPI	LookupAddressIntV4A	(unsigned int ip, pAddr  address);
int	WINAPI	LookupAddressIntV4W	(unsigned int ip, pAddrW address);
int	WINAPI	LookupAddressIntV6A	(unsigned __int64 iplow, unsigned __int64 iphigh, pAddr  address);
int	WINAPI	LookupAddressIntV6W	(unsigned __int64 iplow, unsigned __int64 iphigh, pAddrW address);
int	WINAPI	ReloadDatabase	();
int	WINAPI	ReloadDatabaseEx	(unsigned int idb);
int	WINAPI	ReloadDatabaseWithPathA	(unsigned int idb, const char * fn);
int	WINAPI	ReloadDatabaseWithPathW	(unsigned int idb, const wchar_t * fn);
size_t	WINAPI	lstrcntA	(const char   * str, const char   * strtocount);
size_t	WINAPI	lstrcntW	(const wchar_t* str, const wchar_t* strtocount);
char*	WINAPI	lstrrchrposA	(const char   * str, int ch, const char   * pos);
wchar_t* WINAPI	lstrrchrposW	(const wchar_t* str, int ch, const wchar_t* pos);

#ifdef __cplusplus
}
#endif

#endif
